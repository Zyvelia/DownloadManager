# Z’s Download Manager feature menu

Pick features by number. Items **1–15** are in this build. Items **16–50** are proposals for a future update.

## Included in Z’s Download Manager 1.0

1. **Add a direct URL** from the dashboard.
2. **Send a link by right-click** in Chrome or Edge.
3. **Paste a link into the extension popup** to send it without opening the dashboard.
4. **Run three downloads at once** with the rest held in the queue.
5. **Pause and resume** transfers. Partial files continue when the server supports ranges and provides a strong ETag.
6. **Cancel and retry** downloads from the queue.
7. **See live progress, file size, and transfer rate** while a download runs.
8. **Search the queue and filter by status.**
9. **Keep download history** across app restarts.
10. **Set a default folder or choose a folder for one download.**
11. **Open the destination folder** from a finished transfer.
12. **Choose one of four color themes.**
13. **Use compact rows** to fit more downloads on screen.
14. **Hide optional sidebar tabs and overview sections.**
15. **Choose visible columns separately** for the Overview and Downloads tabs.

## Transfer controls

16. **Batch add** to paste a list of links into the queue.
17. **Queue priorities** to move urgent downloads ahead.
18. **Configurable concurrency** to choose how many transfers run at once.
19. **Global speed limit** to reserve bandwidth for other apps.
20. **Per-download speed limit** for a single large transfer.
21. **Scheduled download windows** to run transfers overnight or off-peak.
22. **Automatic retry with backoff** after temporary network errors.
23. **Reconnect and resume** automatically after a dropped internet connection.
24. **Multi-part downloading** on servers that support parallel byte ranges.
25. **Mirror URLs** so a download can fall back to another host.
26. **Pause all and resume all** from one control.
27. **Hold downloads on metered networks.**
28. **Low disk-space check** before starting a transfer with a known size.
29. **Estimated time remaining** for transfers with a known size.
30. **SHA-256 verification** against a checksum you provide.

## Organization and Windows

31. **Rename before downloading** to choose the exact filename.
32. **Automatic folders by file type** for archives, videos, documents, and installers.
33. **Site-specific save folders** for hosts you use regularly.
34. **Tags and custom categories** for organizing downloads.
35. **Duplicate-link detection** before a second copy enters the queue.
36. **Export history to CSV** for records or spreadsheets.
37. **Import and export settings** for backup or use on another PC.
38. **Windows notifications** for completed or failed downloads.
39. **System tray controls** for opening Z’s Download Manager and pausing the queue.
40. **Start with Windows** as an optional setting.
41. **Light theme and custom accent color.**
42. **Drag-to-reorder sidebar tabs** and save the order.
43. **Customizable keyboard shortcuts** for common actions.

## Browser and file workflows

44. **Preview and choose multiple links on a page** before sending them.
45. **Send a selected image or media URL** from a context menu.
46. **Confirm the destination in the extension** before submitting a link.
47. **Choose whether to intercept browser downloads** using an opt-in list of sites or file types.
48. **Download link metadata preview** showing available filename, type, and size.
49. **Automatic archive extraction** to a chosen folder.
50. **Transfer logs** with timestamps, retry events, and server responses.
