# Z’s Download Manager

Z’s Download Manager 1.0 is a portable download manager for Windows 11. It opens its local dashboard in a dedicated Edge or Chrome app window when either browser is available. It uses the default browser as a fallback.

## Run on Windows 11

1. Extract the release ZIP to a folder you can keep.
2. Open **Z's Download Manager.exe** on most PCs. Use **Z's Download Manager ARM64.exe** on an ARM-based Windows PC. Both executables are unsigned.
3. Click **Add download** and paste a direct HTTP or HTTPS file URL. Optionally enter a full save path such as `D:\Downloads`. The default is the Downloads folder under your Windows user profile.
4. Use **Customize** to choose a color theme, compact rows, visible sidebar tabs, visible overview sections, and visible table columns for each downloads view. Settings stays accessible so you can restore your layout.

Z’s Download Manager runs in the background when you close the dashboard. To reopen it, run the same executable again. Use **Settings → Quit Z’s Download Manager** to stop it. Interrupted transfers appear as paused when you reopen Z’s Download Manager. A server needs to support HTTP ranges and provide a strong ETag for Z’s Download Manager to continue a partial file. Otherwise Resume starts the transfer from the beginning.

The queue runs up to three downloads at once. Z’s Download Manager gives files a numbered suffix if the name already exists. Select **Open folder** to find a finished file. **Remove** clears the entry from the queue or history and retains completed files.

## Install and pair the browser extension

1. Extract **Z's Download Manager Browser Extension.zip** to a permanent folder.
2. In Chrome open `chrome://extensions`. In Edge open `edge://extensions`.
3. Enable **Developer mode**, choose **Load unpacked**, then select the folder containing `manifest.json`.
4. Open the **Browser extension** tab in the app and click **Copy pairing key**.
5. Open the Z’s Download Manager extension from the browser toolbar, paste the key, and click **Save**.
6. Right-click a direct link and choose **Send link to Z’s Download Manager**. The extension also accepts a URL pasted into its popup. Its toolbar badge shows ✓ for accepted and ! if the handoff failed. Open the popup for details.

The extension sends the URL when you ask it to and only connects to Z’s Download Manager at `127.0.0.1:39467`. Signed URLs that work by themselves can be downloaded until they expire. Links that depend on browser cookies, site sign-in, or a `blob:` URL need another download method.

## Build from source

Install Go 1.23 or later, open PowerShell in the source folder, and run:

```powershell
.\build.ps1
```

The script builds the x64 and ARM64 executables in `dist` with the included application icon. The Go build uses the standard library. The unpacked Chromium extension lives in `extension`. To rebuild the browser bundle, ZIP the contents of that folder with `manifest.json` at the root.

The app stores its queue and pairing key under `%APPDATA%\ZDM`. The dashboard stores layout preferences in the browser profile. If Z’s Download Manager fails to open, look for `startup-error.txt` under `%APPDATA%\ZDM` and check whether another application already uses TCP port 39467.
